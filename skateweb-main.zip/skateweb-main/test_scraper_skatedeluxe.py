import sys
import os
from bs4 import BeautifulSoup
from curl_cffi import requests
from app import parse_products, SHOP_CONFIGS, fetch_with_curl

config = SHOP_CONFIGS["skatedeluxe"]
html = fetch_with_curl("https://www.skatedeluxe.com/en/c/skateboards/skateboard-decks?page=1")
if not html:
    print("Failed to fetch")
    sys.exit(1)

soup = BeautifulSoup(html, "html.parser")
sel = config["selectors"]

products = parse_products(soup, sel, config, None, None)

for p in products[:3]:
    print(f"Name: {p.get('name')}")
    print(f"Brand: {p.get('brand')}")
    print("-" * 20)
