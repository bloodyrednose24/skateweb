
import sys
import os
from app import scrape_shop, SHOP_CONFIGS

def test_prebuilts():
    shops = ["tactics", "skatedeluxe", "boards-lv"]
    category = "prebuilts"
    
    for shop in shops:
        print(f"\n--- Results for {shop} ---")
        results = scrape_shop(shop, category)
        print(f"Total results: {len(results)}")
        
        no_complete_kw = []
        for res in results:
            name_lower = res['name'].lower()
            if not any(ok in name_lower for ok in ["complete", "komplekts"]):
                no_complete_kw.append(res)
        
        print(f"Found {len(no_complete_kw)} items without 'complete' or 'komplekts' in name:")
        for i, res in enumerate(no_complete_kw[:50]):
            print(f"  {i+1}. {res['name']} ({res['price']})")

if __name__ == "__main__":
    test_prebuilts()
