
import json
from app import scrape_shop

def test_prebuilts():
    shops = ["boards-lv", "skatedeluxe", "tactics"]
    for shop in shops:
        print(f"\n--- Testing {shop} prebuilts ---")
        results = scrape_shop(shop, "prebuilts")
        print(f"Found {len(results)} products")
        for i, res in enumerate(results[:10]):
            print(f"{i+1}: {res['name']} ({res['shop']})")

if __name__ == "__main__":
    test_prebuilts()
