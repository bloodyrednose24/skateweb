
import os
import sys
sys.path.append(os.getcwd())
from app import scrape_shop

def test_boards_lv():
    print(f"\n--- Testing boards-lv prebuilts ---")
    results = scrape_shop("boards-lv", "prebuilts")
    print(f"Found {len(results)} products")
    for i, res in enumerate(results[:10]):
        print(f"{i+1}: {res['name']}")

if __name__ == "__main__":
    test_boards_lv()
