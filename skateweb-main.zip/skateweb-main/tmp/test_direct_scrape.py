import json
import requests

def test_scrape_wheels():
    url = "http://localhost:5000/api/scrape"
    payload = {
        "shops": ["skatedeluxe"],
        "category": "wheels",
        "filter_size": None,
        "budget": 50
    }
    # Note: This requires the flask app to be running.
    # Since I cannot easily run the flask app and make requests to it in the same turn without backgrounding,
    # I will instead call the `scrape_shop` function directly in a script.
    pass

if __name__ == "__main__":
    from app import scrape_shop
    # Testing trucks from boards.lv (Selenium)
    # filter_size for trucks expects min/max in inches
    filter_size = {"min": 5.0, "max": 5.25}
    results = scrape_shop("boards-lv", "trucks", filter_size=filter_size, budget=100)
    print(f"Found {len(results)} trucks in range 5.0-5.25")
    for r in results[:10]:
        print(f"- {r['name']} ({r['price']}) Size: {r['size']}")
