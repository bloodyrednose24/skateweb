
import sys
import os
from app import parse_products, SHOP_CONFIGS
from bs4 import BeautifulSoup

def test_deck_filtering():
    # Simulate a deck product from skatedeluxe
    html = """
    <div class="listing-product">
        <div class="listing-product-name">Real Ishod Wair Maple 8.25" Skateboard Deck</div>
        <div class="listing-product-price-regular">60,00 EUR</div>
        <a href="/en/real-ishod-wair-deck"></a>
    </div>
    """
    soup = BeautifulSoup(html, "html.parser")
    config = SHOP_CONFIGS["skatedeluxe"]
    sel = config["selectors"]
    
    print("Testing 'prebuilts' category filtering for a Deck...")
    results = parse_products(soup, sel, config, "prebuilts", None, None)
    
    if len(results) == 0:
        print("SUCCESS: Deck was filtered out of prebuilts.")
    else:
        print(f"FAILURE: Deck was NOT filtered out. Result: {results[0]['name']}")

    print("\nTesting 'prebuilts' category filtering for a Complete...")
    html_complete = """
    <div class="listing-product">
        <div class="listing-product-name">Element Section 8.0" Complete Skateboard</div>
        <div class="listing-product-price-regular">99,00 EUR</div>
        <a href="/en/element-complete"></a>
    </div>
    """
    soup_complete = BeautifulSoup(html_complete, "html.parser")
    results_complete = parse_products(soup_complete, sel, config, "prebuilts", None, None)
    
    if len(results_complete) > 0:
        print(f"SUCCESS: Complete was kept. Result: {results_complete[0]['name']}")
    else:
        print("FAILURE: Complete was filtered out.")

if __name__ == "__main__":
    test_deck_filtering()
