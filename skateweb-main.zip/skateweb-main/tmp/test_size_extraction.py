import unittest
from app import extract_size

class TestSizeExtraction(unittest.TestCase):
    def test_decks(self):
        self.assertEqual(extract_size('Skateboard Deck 8.25"', 'decks'), 8.25)
        self.assertEqual(extract_size('Anti Hero Deck 8.0', 'decks'), 8.0)
        self.assertEqual(extract_size('Powell Peralta 9.0', 'decks'), 9.0)
        self.assertEqual(extract_size('Complete 7.75', 'prebuilts'), 7.75)

    def test_trucks(self):
        # Inch sizes
        self.assertEqual(extract_size('Independent Stage 11 5.25"', 'trucks'), 5.25)
        self.assertEqual(extract_size('Thunder Trucks 147 (5.25)', 'trucks'), 5.25)
        self.assertEqual(extract_size('Venture 5.0 High', 'trucks'), 5.0)
        
        # MM sizes
        self.assertEqual(extract_size('Independent 139', 'trucks'), 5.25)
        self.assertEqual(extract_size('Independent 144', 'trucks'), 5.5)
        self.assertEqual(extract_size('Thunder 149', 'trucks'), 5.75)
        self.assertEqual(extract_size('Thunder 169', 'trucks'), 6.25)

    def test_wheels(self):
        self.assertEqual(extract_size('Spitfire 52mm', 'wheels'), 52.0)
        self.assertEqual(extract_size('Bones 54 mm 101a', 'wheels'), 54.0)
        self.assertEqual(extract_size('Ricta Clouds 56', 'wheels'), 56.0)

    def test_fallback(self):
        # Should still find deck-like sizes even without category
        self.assertEqual(extract_size('Random 8.125'), 8.125)

if __name__ == '__main__':
    unittest.main()
